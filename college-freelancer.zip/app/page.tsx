import Link from "next/link"
import Image from "next/image"
import { ArrowRight, BookOpen, Code, Edit, GraduationCap, Search, Star, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">CampusLance</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#" className="text-sm font-medium hover:text-primary">
              Browse Services
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              How It Works
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              Success Stories
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              About Us
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm font-medium hover:text-primary hidden md:block">
              Sign In
            </Link>
            <Button>Join Now</Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <section className="py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 xl:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                    Student Skills, Professional Results
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Connect with talented college students for your projects or showcase your skills to earn while you
                    learn.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <div className="flex-1">
                    <Input placeholder="What service are you looking for?" className="w-full" />
                  </div>
                  <Button size="lg" className="gap-1">
                    <Search className="h-4 w-4" />
                    Search
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                  <span>Popular:</span>
                  <Link href="#" className="underline hover:text-primary">
                    Web Design
                  </Link>
                  <Link href="#" className="underline hover:text-primary">
                    Content Writing
                  </Link>
                  <Link href="#" className="underline hover:text-primary">
                    Graphic Design
                  </Link>
                  <Link href="#" className="underline hover:text-primary">
                    Tutoring
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=500&width=500"
                  width={500}
                  height={500}
                  alt="College students working on laptops"
                  className="rounded-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Browse Popular Categories
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Discover services offered by talented college students across various fields
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-8">
              <Link
                href="#"
                className="group relative overflow-hidden rounded-lg border bg-background p-6 hover:border-primary transition-colors"
              >
                <div className="flex h-full flex-col justify-between">
                  <div className="space-y-2">
                    <Code className="h-10 w-10 text-primary" />
                    <h3 className="font-bold">Programming & Tech</h3>
                    <p className="text-sm text-muted-foreground">
                      Web development, mobile apps, software solutions, and more
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-primary pt-4">
                    <span className="text-sm font-medium">Explore</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
              <Link
                href="#"
                className="group relative overflow-hidden rounded-lg border bg-background p-6 hover:border-primary transition-colors"
              >
                <div className="flex h-full flex-col justify-between">
                  <div className="space-y-2">
                    <Edit className="h-10 w-10 text-primary" />
                    <h3 className="font-bold">Writing & Translation</h3>
                    <p className="text-sm text-muted-foreground">
                      Content creation, academic writing, editing, and proofreading
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-primary pt-4">
                    <span className="text-sm font-medium">Explore</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
              <Link
                href="#"
                className="group relative overflow-hidden rounded-lg border bg-background p-6 hover:border-primary transition-colors"
              >
                <div className="flex h-full flex-col justify-between">
                  <div className="space-y-2">
                    <BookOpen className="h-10 w-10 text-primary" />
                    <h3 className="font-bold">Tutoring & Education</h3>
                    <p className="text-sm text-muted-foreground">
                      Subject tutoring, test prep, research assistance, and mentoring
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-primary pt-4">
                    <span className="text-sm font-medium">Explore</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
              <Link
                href="#"
                className="group relative overflow-hidden rounded-lg border bg-background p-6 hover:border-primary transition-colors"
              >
                <div className="flex h-full flex-col justify-between">
                  <div className="space-y-2">
                    <Users className="h-10 w-10 text-primary" />
                    <h3 className="font-bold">Marketing & Social Media</h3>
                    <p className="text-sm text-muted-foreground">
                      Social media management, SEO, content strategy, and analytics
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-primary pt-4">
                    <span className="text-sm font-medium">Explore</span>
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                  Featured Student Freelancers
                </h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Meet some of our top-rated college talent ready to help with your projects
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-8">
              {[
                {
                  name: "Alex Johnson",
                  university: "Stanford University",
                  major: "Computer Science",
                  rating: 4.9,
                  reviews: 37,
                  image: "/placeholder.svg?height=300&width=300",
                  skills: ["Web Development", "React", "Node.js"],
                },
                {
                  name: "Sophia Chen",
                  university: "NYU",
                  major: "Graphic Design",
                  rating: 4.8,
                  reviews: 42,
                  image: "/placeholder.svg?height=300&width=300",
                  skills: ["UI/UX Design", "Branding", "Illustration"],
                },
                {
                  name: "Marcus Williams",
                  university: "UC Berkeley",
                  major: "English Literature",
                  rating: 4.7,
                  reviews: 28,
                  image: "/placeholder.svg?height=300&width=300",
                  skills: ["Content Writing", "Editing", "Research"],
                },
              ].map((freelancer, index) => (
                <div key={index} className="rounded-lg border bg-background p-6">
                  <div className="flex flex-col items-center text-center">
                    <Image
                      src={freelancer.image || "/placeholder.svg"}
                      width={100}
                      height={100}
                      alt={freelancer.name}
                      className="rounded-full object-cover mb-4"
                    />
                    <h3 className="text-xl font-bold">{freelancer.name}</h3>
                    <p className="text-sm text-muted-foreground">{freelancer.university}</p>
                    <p className="text-sm text-muted-foreground">Major: {freelancer.major}</p>
                    <div className="flex items-center mt-2">
                      <Star className="h-4 w-4 fill-primary text-primary" />
                      <span className="ml-1 text-sm font-medium">{freelancer.rating}</span>
                      <span className="ml-1 text-sm text-muted-foreground">({freelancer.reviews} reviews)</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4 justify-center">
                      {freelancer.skills.map((skill, skillIndex) => (
                        <span
                          key={skillIndex}
                          className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                    <Button variant="outline" className="mt-4 w-full">
                      View Profile
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center mt-8">
              <Button variant="outline" className="gap-1">
                View All Freelancers
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-2 lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How CampusLance Works</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                    Simple steps to connect students with opportunities and clients with talent
                  </p>
                </div>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      1
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Create Your Profile</h3>
                      <p className="text-sm text-muted-foreground">
                        Students showcase their skills, experience, and academic background
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      2
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Browse & Connect</h3>
                      <p className="text-sm text-muted-foreground">
                        Clients browse student profiles or post projects for students to bid on
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      3
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Collaborate & Complete</h3>
                      <p className="text-sm text-muted-foreground">
                        Work together through our platform with messaging, file sharing, and milestone tracking
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      4
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Review & Get Paid</h3>
                      <p className="text-sm text-muted-foreground">
                        Students receive payment and reviews to build their portfolio and reputation
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=500&width=500"
                  width={500}
                  height={500}
                  alt="How it works illustration"
                  className="rounded-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 lg:py-32 bg-muted/40">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Success Stories</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Hear from students and clients who have found success on our platform
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 mt-8">
              {[
                {
                  quote:
                    "CampusLance helped me earn enough to pay for my textbooks and gain real-world experience in my field before graduation.",
                  name: "Jamie Rodriguez",
                  role: "Computer Science Student",
                  university: "MIT",
                },
                {
                  quote:
                    "The quality of work I received from student freelancers exceeded my expectations. Fresh perspectives at affordable rates!",
                  name: "Sarah Thompson",
                  role: "Small Business Owner",
                  company: "Bloom Boutique",
                },
                {
                  quote:
                    "I built my entire portfolio through projects on CampusLance, which helped me land my dream job right after graduation.",
                  name: "David Kim",
                  role: "Graphic Design Graduate",
                  university: "RISD",
                },
              ].map((testimonial, index) => (
                <div key={index} className="rounded-lg border bg-background p-6">
                  <div className="flex flex-col gap-4">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                      ))}
                    </div>
                    <p className="text-muted-foreground">"{testimonial.quote}"</p>
                    <div className="mt-auto">
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      <p className="text-sm text-muted-foreground">{testimonial.university || testimonial.company}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ready to Get Started?</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                  Join thousands of students and clients already connecting on CampusLance
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Button size="lg" className="gap-1">
                  Join as a Student
                </Button>
                <Button size="lg" variant="outline" className="gap-1">
                  Hire a Student
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t bg-muted/40">
        <div className="container flex flex-col gap-6 py-8 md:flex-row md:items-center md:justify-between md:py-12">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">CampusLance</span>
            </div>
            <p className="text-sm text-muted-foreground">Connecting student talent with real-world opportunities</p>
          </div>
          <nav className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            <div className="space-y-3">
              <h4 className="text-sm font-medium">For Students</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Create Profile
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Find Work
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Success Tips
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-medium">For Clients</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Post a Project
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Browse Talent
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Payment Protection
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Community
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Support
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Company</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="#" className="text-muted-foreground hover:text-foreground">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
          </nav>
        </div>
        <div className="border-t py-6">
          <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground">© 2024 CampusLance. All rights reserved.</p>
            <div className="flex gap-4">
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Terms
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Privacy
              </Link>
              <Link href="#" className="text-sm text-muted-foreground hover:text-foreground">
                Cookies
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

